<?php ob_start();
include("include/header.php");
include("include/sidebar.php");
?>


  <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">کتگوری جدید</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="col-sm-3"></div>
            <div class="row col-sm-6">
              <div class="panel panel-default ">
                 <div class="panel-heading"><h4> افزودن کتگوری جدید</h4></div>

                 <div class="panel-body">
                       <form method="post">
                       	 <div class="form-group">
                       	 	<input type="text" name="cat_name" id="cat_name" placeholder="اسم کتگوری" class="form-control" required>
                       	 </div>
                         <div class="form-group">
                            <label for="description">توضیحات</label>
                            <textarea class="form-control" rows="5" name="description" id="description"> </textarea>
                         </div>
                          <div class="form-group">
                            <input type="submit" name="submit"  value="ذخیره" class="form-control btn-info">
                         </div>
                       </form>
                       <?php 
                        if(isset($_POST['submit'])){
                          $cat_name=$_POST['cat_name'];
                          $cat_desc=$_POST['description'];

                         $res= $conn->query("insert into category(category_name,category_description) values('$cat_name','$cat_desc')");

                         if($res){
                          header("location:add_category.php?msg=added");
                         }
                         else{
                          echo mysqli_error($conn);
                          //header("location:add_category.php?msg=notAdded");
                         }
                        }
                       

                       if(isset($_GET['msg'])){
                        $message=$_GET['msg'];
                        if($message=="added"){
                          echo "<script>alert('کتگوری جدید موفقانه ایجاد گردید');</script>";
                          ob_end_flush();
                        }
                        else if($message=="notAdded"){
                          echo "<script>alert('لطفا دوباره کوشش کنید');</script>";
                        }
                       }

                       ?>
                </div>
              </div>
            </div>
            <!-- /.row -->
        

    </div>
    <!-- /#wrapper -->






<?php 
include("include/footer.php");
?>