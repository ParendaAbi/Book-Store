        <div id="page-wrapper">
      
            <br>
            <div class="row">
              <div class="panel panel-default">
                 <div class="panel-heading"><h4>پروفایل مدیر </h4>
                 <div class="alert alert-success" style="display:none;"></div>
                 </div>

                 <div class="panel-body">
                    <div class="col-lg-3">
					    <img src="images/admin.jpg" width="180"><br><br>
						<table class="table table-bordered">
						  <tr><td><a id="editUserBtn" ><i class="fa fa-edit">&nbsp;</i>ویرایش پروفایل</a></td></tr>
						  <tr><td><a  id="newUser" ><i class="fa fa-plus">&nbsp;</i>کارمند جدید</a> </td></tr>
						</table>
					</div>
					<div class="col-lg-9"> 
					   <table class="table table-bordered table-striped">
					     <tr><td>اسم</td><td id="name">محمد</td></tr>
					     <tr><td>تخلص</td><td id="lastname">احمدی</td></tr>
					     <tr><td>شماره تماس</td><td id="phone">0787676564</td></tr>
					     <tr><td>ایمل آدرس</td><td id="email">mohammad_ahmadi@yahoo.com</td></tr>
					     <tr><td>دیگر معلومات</td><td>دیگر معلومات</td></tr>
					     <tr><td>دیگر معلومات</td><td>دیگر معلومات</td></tr>
					     <tr><td>دیگر معلومات</td><td>دیگر معلومات</td></tr>
					     <tr><td>آدرس</td><td id="address" colspan=2>هرات- شهر نو- دوکان احمدی</td></tr>
					     
					   </table>
					</div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.row -->
        

    </div>
    <!-- /#wrapper -->


<!-- Trigger the modal with a button -->
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">اضافه کردن کاربر جدید</h4>
      </div>
      <div class="modal-body">
        <form method="post">
                       	 <div class="form-group">
                       	 	<input type="text" name="name"  placeholder="اسم" class="form-control" required>
                       	 </div>
						 
						 <div class="form-group">
                       	 	<input type="text" name="lname"  placeholder="تخلص" class="form-control" required>
                       	 </div>
						 
						 <div class="form-group">
                       	 	<input type="text" name=""  placeholder="شماره تماس" class="form-control" required>
                       	 </div>
						 
						 <div class="form-group">
                       	 	<input type="text" name="lname"  placeholder="ایمیل آدرس" class="form-control" required>
                       	 </div>
						 
						  <div class="form-group">
                       	 	<input type="text" name="uname"  placeholder="نام کاربری" class="form-control" required>
                       	 </div>
						 
						   <div class="form-group">
                       	 	<input type="password" name="pass"  placeholder="رمز عبور" class="form-control" required>
                       	 </div>
						 
                          <div class="form-group">
                            <input type="submit" name="submit"  value="ذخیره" class="form-control btn-info">
                         </div>
                       </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">بسته کردن صفحه</button>
      </div>
    </div>

  </div>
</div>



   <!--
   second  modal 
   -->

   
   <div id="editUserModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">ویرایش کاربر فعلی</h4>
        </div>
        <div class="modal-body">
          <form method="post" id="editUserForm" action="<?php echo base_url(); ?>UsersController/updateUserData">
                         	 <div class="form-group">
                         	 	<input type="text" name="name"  placeholder="اسم" class="form-control" required>
                         	 </div>
  						 
  						 <div class="form-group">
                         	 	<input type="text" name="lname"  placeholder="تخلص" class="form-control" required>
                         	 </div>
  						 
  						 <div class="form-group">
                         	 	<input type="text" name="phone"  placeholder="شماره تماس" class="form-control" required>
                         	 </div>
  						 
  						 <div class="form-group">
                         	 	<input type="text" name="email"  placeholder="ایمیل آدرس" class="form-control" required>
                         	 </div>
  						 
  						  <div class="form-group">
                         	 	<input type="text" name="uname"  placeholder="نام کاربری" class="form-control" required>
                         	 </div>
  						 
  						   <div class="form-group">
                         	 	<input type="password" name="pass"  placeholder="رمز عبور" class="form-control" required>
                         	 </div>
  						 
  						 
  						 
                         </form>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-info" id="saveEditBtn" data-dismiss="modal">ذخیره</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">بسته کردن صفحه</button>
        </div>
      </div>

    </div>
</div>
<!-- /.row -->

<script type="text/javascript">


	$('#newUser').click(function(){
		$('#editUserForm')[0].reset();
		$('#editUserModal').modal('show');
		$('#editUserForm').attr('action', '<?php echo base_url(); ?>UsersController/saveNewUser');
		$('#editUserModal').find('.modal-title').text('Add New User');
	});

	$('#saveEditBtn').click(function(){
		var data = $('#editUserForm').serialize();
		var url = $('#editUserForm').attr('action');

		$.ajax({
			url: url,
			method: 'post',
			type: 'ajax',
			async: false, 
			dataType: 'json',
			data: data,
			success: function(response){
				if (response.success) {
					var type = response.type;
					$('.alert-success').fadeIn().text('You successfully '+type+' a your user account').delay(4000).fadeOut();
					showData();
				}
			},
			error: function(){
				alert('error editing user line 163');
			}
		});
	});
	
	$('#editUserBtn').click(function(){
		var id = '<?php echo $this->session->userdata('user_id'); ?>';
		$('#editUserModal').find('.modal-title').text('Edit some User');
		$('#editUserForm')[0].reset();
		
		$.ajax({
			url : '<?php echo base_url(); ?>UsersController/getUserData',
			async: false, 
			method: 'post',
			data: {id: id},
			type: 'ajax',
			dataType: 'json',
			success: function(data){

				$('#editUserModal').modal('show');
				$('input[name=name]').val(data.name);
				$('input[name=lname]').val(data.lastname);
				$('input[name=phone]').val(data.phone);
				$('input[name=email]').val(data.email);
				$('input[name=uname]').val(data.user_name);
				$('input[name=pass]').val(data.password);
				
				
					
			},
			error: function(){
				
			}
		}); 
	});

	$(document).ready(function(){
		
		showData();

		function showData(){
			var id = '<?php echo $this->session->userdata('user_id'); ?>';
			
			$.ajax({
				url : '<?php echo base_url(); ?>UsersController/getUserData',
				async: false, 
				method: 'post',
				data: {id: id},
				type: 'ajax',
				dataType: 'json',
				success: function(data){
	 
					$('td#name').text(data.name);
					$('td#lastname').text(data.lastname);
					$('td#phone').text(data.phone);
					$('td#email').text(data.email);
					$('td#address').text(data.address); 
					
					
						
				},
				error: function(){
					
				}
			}); 
		}
	});

</script>