            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a class="active" href="<?php echo base_url(); ?>"><i class="fa fa-home fa-fw"></i>صفحه اصلی </a>
                        </li>
                        
                         <li>
                            <a href="#"><i class="fa fa-book fa-fw"></i> کتابها<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo base_url(); ?>BooksController/addBook"><i class="fa fa-plus">&nbsp;</i>افزودن کتاب</a>
                                </li>
                                <li>
                                    <a ><i class="fa fa-plus">&nbsp;</i> کتگوری جدید</a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url(); ?>BooksController/booksList"><i class="fa fa-list-ul">&nbsp;</i>لیست کتگوری ها </a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        

                           <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> فروشات<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo base_url(); ?>BooksController/sellBook">فروش کتاب</a>
                                </li>
                                <li>
                                    <a href="manage_selling.php">لیست فروشات</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                           <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> مصارف<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="book_purchase.php">خرید کتاب</a>
                                </li>
                                <li>
                                    <a href="manage_purchasing.php">لیست خرید کتاب</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                       <li>
                            <a href="#"><i class="fa fa-user fa-fw"></i> مشتری ها<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="add_customer.php"> مشتری جدید</a>
                                </li>
                                <li>
                                    <a href="morris.html">لیست مشتریها</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="reports.php"><i class="fa fa-file fa-fw"></i> گزارشات</a>
                            
                            <!-- /.nav-second-level -->
                        </li>
                           <li>
                            <a href="setting.php"><i class="fa fa-cog fa-fw"></i> تنظیمات
                            
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>BooksController/userProfile"><i class="fa fa-user fa-fw"></i> پروفایل کاربر</a>
                        </li>
                 
                      
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>