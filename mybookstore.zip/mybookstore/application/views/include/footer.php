    <!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.10.2.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="js/raphael/raphael.min.js"></script>
    <script src="js/morris/morris.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>
    <script type="text/javascript" src="assets/dataTables/jquery.dataTables.js"></script>
    <script type="text/javascript" src="assets/dataTables/dataTables.bootstrap.js"></script>

   <script type="text/JavaScript">
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
</body>

</html>
