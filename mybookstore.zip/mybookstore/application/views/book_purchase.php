<?php ob_start();
include("include/header.php");
include("include/sidebar.php");
?>


  <div id="page-wrapper" style="min-height: 900px !important">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">خرید کتاب</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="col-sm-3"></div>
            <div class="row col-sm-6">
              <div class="panel panel-default ">
                 <div class="panel-heading"><h4> فرم خرید کتاب  </h4></div>

                 <div class="panel-body">
                       <form method="post">
                       	 <div class="form-group">
                       	 	<input type="text" name="book_name" id="book_name" placeholder="اسم کتاب" class="form-control">
                       	 </div>
						 
                       	 <div class="form-group">
                       	 	<input type="text" name="book_price" id="book_price" placeholder="قیمت" class="form-control">
                       	 </div>
						 
						 <div class="form-group">
                       	 	<input type="text" name="book_num" id="book_num" placeholder="تعداد" class="form-control">
                       	 </div>
						 
						  <div class="form-group">
                       	 	<input type="date" name="purchase_date" id="purchase_date" placeholder="تاریخ خرید" class="form-control">
                       	 </div>
                        <div class="form-group">
                       	 	<input type="number" name="paid_money" id="paid_money" placeholder="پول  پرداخت شده" class="form-control">
                       	 </div>
                       	
                          <div class="form-group">
                            <input type="submit" name="submit"  value="ذخیره" class="form-control btn-info">
                         </div>
                       </form>
                </div>
              </div>
            </div>
            <!-- /.row -->
    
    </div>
    <!-- /#wrapper -->






<?php 
include("include/footer.php");
?>