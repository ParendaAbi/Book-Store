<?php

   $p = $_POST['vv'];
   
   
   echo $p;


?>