
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">لیست کتابها</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
              <div class="panel panel-default">
                 <div class="panel-heading">
                    <div class="alert alert-success" style="display:none;"></div>
                 <h4>لیست کتابها</h4></div>

                 <div class="panel-body">
                      <div id="search" class="form-group col-sm-3"> 
                      <form method="post">
                          <label for="searchedWord">جستجو</label>
                          <input type="text" name="searchedWord" id="searchedWord" placeholder="جستجو" class="form-control">
                      </form>
                   </div>

                   <div id="select_record" class="form-group col-sm-2">
                    <label for="records">تعداد کتاب در هر صفحه</label>
                       <select name="records" id="records" class="form-control">
                           <option value="10">10</option>
                           <option value="25">25</option>
                           <option value="50">50</option>
                           <option value="100">100</option>
                       </select>
                   </div>

                     <table class="table table-striped table-bordered" id="dataTables-example">
                     <thead>
                     <tr>
                        <th>اسم کتاب</th>
                        <th width="100">قیمت</th>
                        <th>نویسنده</th>
                        <th>مترجم</th>
                        <th>ناشر</th>
                        <th width="300">تنظیمات</th>
                     </tr>
                     </thead>

                     <tbody id="booksTable">

                     <tr>
                         <td>تاریخ معاصر افغانستان</td>
                         <td>400</td>
                         <td>احمد کریمی</td>
                         <td>حسن امیری</td>
                         <td>قدس</td>
                         <td>
                           <button class="btn btn-success" data-toggle="modal" data-target="#edit2"><i class="fa fa-edit">&nbsp;</i>ویرایش</button>
                           <button class="btn btn-danger" data-toggle="modal" data-target="#delete"><i class="fa fa-remove">&nbsp;</i>حذف</button>
                           <button class="btn btn-warning" data-toggle="modal" data-target="#more_info"><i class="fa fa-remove">&nbsp;</i>جزئیات کامل</button>
                          
                         </td>
                     </tr>
                       <tr>
                         <td>آیین زندگی</td>
                         <td>500</td>
                         <td>دیل کارنگی</td>
                         <td>میترا کیوان مهر</td>
                         <td> انتشارات محصلان</td>
                         <td>
                            <button class="btn btn-success"><i class="fa fa-edit">&nbsp;</i>ویرایش</button>
                           <button class="btn btn-danger"><i class="fa fa-remove">&nbsp;</i>حذف</button>
                           <a href="drug_info.php" class="btn btn-warning"><i class="fa fa-info">&nbsp;</i>جزئیات کامل</a>
                         </td>
                     </tr>
                     </tbody>
                     </table>

                   <div class="col-sm-5"><p>شماره 1 الی 2 از 2</p></div>
                     <div class="col-sm-7">
                      <ul class="pager">
                      <li class="previous"><a href="#">قبلی</a></li>
                            
                             <ul class="pagination">
                              <li><a href="#">1</a></li>
                              <li class="active"><a href="#">2</a></li>
                              <li><a href="#">3</a></li>
                              <li><a href="#">4</a></li>
                              <li><a href="#">5</a></li>
                            </ul>
                      <li class="next"><a href="#">بعدی</a></li>
                    </ul>
                      
                  </div>

                  </div>
                </div>
              </div>
            </div>
            <!-- /.row -->
        
		
	<div id="detailsModal" class="modal fade" role="dialog" >
  <div class="modal-dialog" style='width:70%'>

    <!-- Modal content-->
    <div class="modal-content" >
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">چزییات کامل کتاب</h4>
      </div>
      <div class="modal-body" >

	  
                     <table class="table table-striped table-bordered" >
                      <thead>
                       <tr>
                         <th>اسم کتاب</th><th width="100">قیمت</th><th>تعداد کتاب</th><th>جلد</th><th>ویرایش</th><th>نویسنده</th><th>ناشر</th><th>تاریخ نشر</th><th>کتگوری</th>
                       </tr>
                      </thead>
                      <tbody>
                       <tr>
                        <td id="det_name"> تاریخ معاصر </td> <td id="det_price"> 180 افغانی </td><td id="det_number">120</td>
                        <td id="det_volume">1</td><td id="det_edition">دوم</td> <td id="det_author"> احمد امیری</td>
                         <td id="det_publisher"> انتشارات قدس </td><td id="det_publish_date">1396/3/15</td>
                        <td id="det_category">تاریخ</td>
                     </tr> 
                     </tbody>
                     </table>
	  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">بسته کردن صفحه</button>
      </div>
    </div>

  </div>
</div>


<!-- 

  second popup
  
  -->
  
  	<div id="deleteModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">حذف</h4>
      </div>
      <div class="modal-body">
     <h3>آیا مطمین هستید که میخواهید اصلاعات را حذف کنید ؟</h3>
      </div>
      <div class="modal-footer">
        <button type="button" id="deleteBtn" class="btn btn-default">بلی</button>
        <button type="button" data-dismiss="modal" class="btn btn-default" data-dismiss="modal">خیر</button>
      </div>
    </div>

  </div>
</div>
		
    

		
		<div id="editModal" class="modal fade" role="dialog">
  <div class="modal-dialog" >

    <!-- Modal content-->
    <div class="modal-content" >
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ویرایش کتاب</h4>
      </div>
      <div class="modal-body">
       
        <form method="post" action="" id="editForm">
         <input type="hidden" name="hiddenId" value="">
                       	 <div class="form-group">
                       	 	<input type="text" name="book_name"  placeholder="اسم کتاب" class="form-control" >
                       	 </div>
						 
						 <div class="form-group">
                       	 	<input type="text" name="price"  placeholder="قیمت" class="form-control" >
                       	 </div>
						 
						 <div class="form-group">
                       	 	<input type="text" name="writer"  placeholder="نویسنده" class="form-control" >
                       	 </div>
						 
						 <div class="form-group">
                       	 	<input type="text" name="translator"  placeholder="مترجم" class="form-control" >
                       	 </div>
						 
						  <div class="form-group">
                       	 	<input type="text" name="publish"  placeholder="ناشر" class="form-control" >
                       	 </div>
						 
						   <div class="form-group">
                       	 	<input type="date" name="pub_date"  placeholder="تاریخ نشر" class="form-control" >
                       	 </div>
						 
						 <div class="form-group">
                       	 	<input type="text" name="category"  placeholder="کتگوری" class="form-control" >
                       	 </div>
						 
						 
						  
                       </form>
      </div>
      <div class="modal-footer">
        <button  name="submit" id="editBtn" value="ذخیره" class="btn btn-info">zakhira</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">بسته کردن صفحه</button>
      </div>
    </div>

  </div>
</div>

		
    </div>
    <!-- /#wrapper -->

    <script type="text/javascript">
  $(document).ready(function(){



    $('#booksTable').on('click', '.item-details', function(){
      var id = $(this).attr('data');
      $('#detailsModal').modal('show');

      $.ajax({
        url: '<?php echo base_url(); ?>BooksController/getBookInfo',
        async: false,
        method: 'post',
        dataType: 'json',
        data: {id, id},
        success: function(data){
          $('td#det_name').text(data.title);  
          $('td#det_publisher').text(data.publisher);
          $('td#det_publish_date').text(data.publish_date);
          $('td#det_author').text(data.author);
          $('td#det_edition').text(data.edition);
          $('td#det_volume').text(data.jeld);
          $('td#det_number').text(data.period); // what is number in book table
          $('td#det_category').text('category');
          $('td#det_price').text(data.price);
 
        }
      });
    });




    $('#booksTable').on('click', '.item-delete', function(){
        var id = $(this).attr('data');
        $('#deleteModal').modal('show');

        $('#deleteBtn').click(function(){
          $.ajax({
            url: '<?php echo base_url(); ?>BooksController/deleteBook',
            type: 'ajax',
            method: 'post',
            data: {id: id},
            dataType: 'json',
            success: function(){
              $('#deleteModal').modal('hide');
              showAllBooks();
              $('.alert-success').fadeIn().text('You successfully deleted an account!').delay(4000).fadeOut();
            },
            error: function(){
              $('#deleteModal').modal('hide');
              showAllBooks();
              $('.alert-success').fadeIn().text('You successfully deleted an account!').delay(4000).fadeOut();
            }
          });
        });

    });


    $('#editBtn').click(function(){
       var url = $("#editForm").attr('action');
       var data = $('#editForm').serialize();


       $.ajax({
          type: 'ajax',
          method: 'post',
          url: url,
          data: data,
          dataType: 'json',
          async: false,
          success: function(){
            $('#editModal').modal('hide');
            $('#editForm')[0].reset();
            showAllBooks();
          },
          error: function(response){
            $('#editModal').modal('hide');
            $('#editForm')[0].reset();
            showAllBooks();
            $('.alert-success').fadeIn().text('You successfully edited an account!').delay(4000).fadeOut();
          }

       });

    });

    $('#booksTable').on('click', '.item-edit', function(){
       var id = $(this).attr('data');
       $('#editModal').modal('show');
       $('input[name=hiddenId]').val(id);
       $('#editForm').attr('action', '<?php echo base_url(); ?>BooksController/updateBookInfo');

       $.ajax({
        method: 'post',
        async: false,
        dataType: 'json',
        data: {id: id},
        url: '<?php echo base_url(); ?>BooksController/getBookInfo',
        success: function(data){
          $('input[name=book_name]').val(data.title);
          $('input[name=price]').val(data.price);
          $('input[name=writer]').val(data.author);
          $('input[name=translator]').val(data.translator);
          $('input[name=publish]').val(data.publisher);
          $('input[name=pub_date]').val(data.publish_date);
          $('input[name=category]').val('category');
        },
        error: function(){
          alert('failure edit');
        }
       });

    });

    showAllBooks();

    function showAllBooks(key, cat){
      var url;
      var data = [];
      if (!key) {
        url = '<?php echo base_url(); ?>BooksController/getAllBooks';
        
      }else {
        //alert(arguments[0]);
        key = arguments[0];
        cat = arguments[1];
        data = {key: key, cat: cat};
        url = '<?php echo base_url(); ?>BooksController/searchBooks';
         
      }
      $.ajax({
        url: url,
        dataType: 'json',
        type: 'ajax',
        data: data,
        method: 'post',
        type: 'ajax',
        async: false,
        success: function(data){
            var html = '';
            var i;

            if (data.length > 0) {
              for(i=0; i<data.length; i++){
              html += '<tr>'+
                          '<td>'+data[i].title+'</td>'+
                          '<td>'+data[i].price+'</td>'+
                          '<td>'+data[i].author+'</td>'+

                          '<td>'+data[i].translator+'</td>'+
                          '<td>'+data[i].publisher+'</td>'+ 
                          '<td> <button class="btn btn-success item-edit" data='+data[i].book_id+'>ویرایش</button>'+
                                '<button class="btn btn-danger item-delete" data='+data[i].book_id+'>Delete</button>'+ 
                                '<button class="btn btn-info item-details" data='+data[i].book_id+'>Details</button>'+ 
                          '</td>';
                 }
            }
            
            $('#booksTable').html(html);
        },
        error: function(jqXHR, exception){
          $('#booksTable').html('<tr><td>Not found</td></tr>');
        }
      });
    }



    //search according to
    //Search section
    $('#searchedWord').keyup(function(){
      var searchKey = $('input[name=searchedWord]').val();
      var searchCategory = $('#searchCategory').find(":selected").val();
      //alert ('SELECT * FROM book WHERE '+searchCategory+' LIKE '+searchKey);
      showAllBooks(searchKey, searchCategory);
    });

     
    


  });
  </script>
  
