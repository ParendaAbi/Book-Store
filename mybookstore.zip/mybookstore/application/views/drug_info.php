<?php 

include("include/header.php");
include("include/sidebar.php");
//start of main content 
?>

<div id="page-wrapper">
    <div class="row">
	  <div class="col-lg-12">
	     <h1 class="page-header">مشخصات کامل دوا</h1>
	  </div>
    </div>

    <div class="panel panel-default">
    	<div class="panel-heading">
    		<h4>مشخصات کامل دوا</h4>
    		<div class="return">
    			<a href="Manage_Drug.php"><img src="images/back.png"></a>
    		</div>
    	</div>
        <div class="panel-body">
	     	<table class="table table-striped table-bordered">
	     		<tr>
	     		  <th>اسم دوا</th><th>قیمت</th><th>تاریخ تولید</th><th>تاریخ انقضاء</th><th>کمپنی تولید کننده</th><th>کمپنی وارد کننده</th>
	     		</tr>
	     		
	     		<tr>
	     		  <td>انسولین</td><td>400</td><td> 1396/3/23</td><td>1397/4/23</td><td>شرکت آسیا فارما</td><td>آسای فارما</td>
	     		</tr>
	     		<tr>
	     			<td colspan="6">افغانستان - هرات - شهر نو</td>
	     		</tr>
	     		
	     	</table>
	    </div>
    </div>
</div>

<?php
include("include/footer.php");

?>