
<?php 

include("include/header.php");
include("include/sidebar.php");
//start of main content 
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">لیست موجودی</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
              <div class="panel panel-default">
                 <div class="panel-heading"><h4>لیست موجودی دوکان</h4></div>

                 <div class="panel-body">

                 
                   <div id="select_record" class="form-group col-sm-2">
                    <label for="records">تعداد فروش در هر صفحه</label>
                       <select name="records" id="records" class="form-control">
                           <option value="10">10</option>
                           <option value="25">25</option>
                           <option value="50">50</option>
                           <option value="100">100</option>
                       </select>
                   </div>

                     <table class="table table-striped table-bordered">
                     <tr>
                        <th>اسم کتاب</th>
                        <th width="100">قیمت</th>
                        <th>تعداد کتاب در دوکان </th>
                        <th>تعداد کتاب در گدام</th>
                      
                     </tr>
                   
                     <tr>
                         <td>انسولین</td>
                         <td>120</td>
                         <td>500</td>
                         <td>1397/3/21</td>
						
                     </tr>
                     <tr>
                         <td>مورفین</td>
                         <td>60</td>
                         <td>230</td>
                         <td>1397/3/21</td>
						
                     </tr>
                     </table>

                    <div class="col-sm-5"><p>شماره 1 الی 2 از 2</p></div>
                     <div class="col-sm-7">
                      <ul class="pager">
                      <li class="previous"><a href="#">قبلی</a></li>
                            
                            <ul class="pagination">
                              <li><a href="#">1</a></li>
                              <li class="active"><a href="#">2</a></li>
                              <li><a href="#">3</a></li>
                              <li><a href="#">4</a></li>
                              <li><a href="#">5</a></li>
                            </ul>
                      <li class="next"><a href="#">بعدی</a></li>
                    </ul>
                      
                  </div>
                </div>
              </div>
            </div>
            <!-- /.row -->
        

    </div>
    <!-- /#wrapper -->


<?php
include("include/footer.php");

?>