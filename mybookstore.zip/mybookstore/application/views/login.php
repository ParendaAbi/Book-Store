<!DOCTYPE html>
<?php session_start(); ?>
<html >
<head>
  <meta charset="UTF-8">
  <title>ورود به سیستم</title>
  
  
  
      <link rel="stylesheet" href="css/login_style.css">
    
  
</head>

<body>
  <body>
	<div class="login">
	<center><h1 style='color:white;'>انتشارات اقبال</h1></center>
		<div class="login-screen">
			<div class="app-title">
				<h1>ورودبه سیستم</h1>
			</div>
	
			<div class="login-form">
			<form method="post">
				<div class="control-group">
				<input type="text" name="username" class="login-field" value="" placeholder="نام کاربری" id="login-name">
				<label class="login-field-icon fui-user" for="login-name"></label>
				</div>

				<div class="control-group">
				<input type="password" name="password" class="login-field" value="" placeholder="رمز عبور" id="login-pass">
				<label class="login-field-icon fui-lock" for="login-pass"></label>
				</div>
				<input type="submit" name="login" value="ورود" class="btn btn-primary btn-large btn-block" >
<?php 
	$connection = mysqli_connect("localhost","root","","bookstore");
	if (!$connection){
		echo "اتصال با دیتابیس برقرار نشد!";
	}
	if (isset($_POST['login'])){
		
	$uname = $_POST['username'];
	$pass = $_POST['password'];
	
	$query = "SELECT * FROM user WHERE user_name ='$uname' AND password ='$pass'";
	
	$qresult = mysqli_query($connection,$query);
	if (mysqli_num_rows($qresult) == 1){
		$_SESSION['login'] = $uname;
		header("location:index.php");
	}else{
		?><span class="msg">
		<?php echo "!نام کاربری یا رمز عبور شما درست نیست ";?>
		  </span>
		  <a href="#" class="forgotpass">رمز عبور تان را فراموش کرده اید؟</a>
		  <?php
	}
	}
?>
			</form>
			</div>
		</div>
	</div>
</body>

  	
</body>
</html>
