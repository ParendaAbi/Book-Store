
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">صفحه اصلی</h2>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
              <div class="panel panel-default">
                 <div class="panel-heading"><h4>لیست کتابها</h4></div>

                 <div class="panel-body">

				
				
                   <div id="search" class="form-group col-sm-3"> 
                      <form >
                          <label for="searchedWord">جستجو</label>
                          <input type="SEARCH" name="searchedWord" style="display:inline;" id="searchedWord" placeholder="جستجو" class="form-control" list="books">
     
                          <datalist id="books">
                            <option>تاریخ معاصر</option>
                            <optgroup>آیین زندگی</option>
                            <option>آداب سخن</option>
                            <option>تولی دیگر</option>
                            <option>تفسیر قرآن</option>
                            <option>احادیث پیامبر</option>
                            <option>احادیث پیامبر 2</option>
                          </datalist>
 
                            <select class="form-control" id="searchCategory" style="float:right;">
                              <option value="title">اسم کتاب</option>
                              <option value="author">نویسنده</option>
                              <option value="publisher">ناشر</option>
                              <option value="category">کتگوری</option>
                            </select>

                      </form>
                   </div>

                     <table class="table table-striped table-bordered" >
                      <thead>
                       <tr>
                         <th>اسم کتاب</th><th width="100">قیمت</th><th>تعداد کتاب</th><th>جلد</th><th>ویرایش</th><th>نویسنده</th><th>ناشر</th><th>تاریخ نشر</th><th>کتگوری</th>
                       </tr>
                      </thead>
                      <tbody id="booksTable">
                       <tr>
                        <td> تاریخ معاصر </td> <td> 180 افغانی </td><td>120</td><td>1</td><td>دوم</td> <td> احمد امیری</td> <td> انتشارات قدس </td><td>1396/3/15</td>
                        <td>تاریخ</td>
                     </tr>
                       
                     </tbody>
                     </table>

                </div>
              </div>
            </div>
            <!-- /.row -->
        

    </div>
    <!-- /#wrapper -->
  <script type="text/javascript">
  $(document).ready(function(){

    showAllBooks();

    function showAllBooks(key, cat){
      var url;
      var data = [];
      if (!key) {
        url = '<?php echo base_url(); ?>BooksController/getAllBooks';
        
      }else {
        //alert(arguments[0]);
        key = arguments[0];
        cat = arguments[1];
        data = {key: key, cat: cat};
        url = '<?php echo base_url(); ?>BooksController/searchBooks';
         
      }
      $.ajax({
        url: url,
        dataType: 'json',
        type: 'ajax',
        data: data,
        method: 'post',
        type: 'ajax',
        async: false,
        success: function(data){
            var html = '';
            var i;

            if (data.length > 0) {
              for(i=0; i<data.length; i++){
              html += '<tr>'+
                          '<td>'+data[i].title+'</td>'+
                          '<td>'+data[i].price+'</td>'+
                          '<td>'+data[i].period+'</td>'+
                          '<td>'+data[i].jeld+'</td>'+
                          '<td>'+data[i].edition+'</td>'+

                          '<td>'+data[i].author+'</td>'+
                          '<td>'+data[i].publisher+'</td>'+
                          '<td>'+data[i].publish_date+'</td>'+
                          '<td> Category Unknown yet </td>';
                 }
            }
            
            $('#booksTable').html(html);
        },
        error: function(jqXHR, exception){
          $('#booksTable').html('<tr><td>Not found</td></tr>');
        }
      });
    }

    //search according to
    //Search section
    $('#searchedWord').keyup(function(){
      var searchKey = $('input[name=searchedWord]').val();
      var searchCategory = $('#searchCategory').find(":selected").val();
      //alert ('SELECT * FROM book WHERE '+searchCategory+' LIKE '+searchKey);
      showAllBooks(searchKey, searchCategory);
    });

     
    


  });
  </script>
  