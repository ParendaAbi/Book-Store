
<?php 

include("include/header.php");
include("include/sidebar.php");
//start of main content 
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">لیست فروشات</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
              <div class="panel panel-default">
                 <div class="panel-heading"><h4>لیست فروشت</h4></div>

                 <div class="panel-body">

                   <div id="search" class="form-group col-sm-3"> 
                      <form method="post">
                          <label for="searchedWord">جستجو</label>
                          <input type="text" name="searchedWord" id="searchedWord" placeholder="جستجو" class="form-control">
                      </form>
                   </div>

                   <div id="select_record" class="form-group col-sm-2">
                    <label for="records">تعداد فروش در هر صفحه</label>
                       <select name="records" id="records" class="form-control">
                           <option value="10">10</option>
                           <option value="25">25</option>
                           <option value="50">50</option>
                           <option value="100">100</option>
                       </select>
                   </div>

                     <table class="table table-striped table-bordered">
                     <tr>
                        <th>اسم کتاب</th>
                        <th width="100">قیمت</th>
                        <th>تعداد فروش </th>
                        <th>تاریخ فروش</th>
                        <th>خرید کننده  </th>
                        <th>پول پداخت شده  </th>
                        <th>پول باقی مانده   </th>
                        <th>مقدار کل  </th>
                        <th >تنظیمات</th>
                     </tr>

                     <tr>
                         <td>انسولین</td>
                         <td>120</td>
                         <td>500</td>
                         <td>1397/3/21</td>
						  <td>محمد احمدی</td>
						 <td>45000</td>
						 <td>15000</td>
                        <td>60000</td>
                         <td>
                           <button class="btn btn-success"><i class="fa fa-edit">&nbsp;</i>ویرایش</button>
                           <button class="btn btn-danger"><i class="fa fa-remove">&nbsp;</i>حذف</button>
                         </td>
                     </tr>
                       <tr>
                         <td>مورفین</td>
                         <td>60</td>
                         <td>230</td>
                         <td>1397/3/21</td>
						  <td>علی حمیدی</td>
						 <td>12000</td>
						 <td>1800</td>
                        <td>13800</td>
                         <td>
                            <button class="btn btn-success"><i class="fa fa-edit">&nbsp;</i>ویرایش</button>
                           <button class="btn btn-danger"><i class="fa fa-remove">&nbsp;</i>حذف</button>
                         </td>
                     </tr>
                     </table>

                    <div class="col-sm-5"><p>شماره 1 الی 2 از 2</p></div>
                     <div class="col-sm-7">
                      <ul class="pager">
                      <li class="previous"><a href="#">قبلی</a></li>
                            
                             <ul class="pagination">
                              <li><a href="#">1</a></li>
                              <li class="active"><a href="#">2</a></li>
                              <li><a href="#">3</a></li>
                              <li><a href="#">4</a></li>
                              <li><a href="#">5</a></li>
                            </ul>
                      <li class="next"><a href="#">بعدی</a></li>
                    </ul>
                      
                  </div>
                </div>
              </div>
            </div>
            <!-- /.row -->
        

    </div>
    <!-- /#wrapper -->


<?php
include("include/footer.php");

?>