  <div id="page-wrapper" style="min-height: 900px !important">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">افزودن کتاب</h2>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="col-sm-3"></div>
            <div class="row col-sm-6">
              <div class="panel panel-default ">
                 <div class="panel-heading"><h4> افزودن کتاب جدید</h4>
                 <div class="alert alert-success" style="display:none;"></div>
                 </div>

                 <div class="panel-body">
                       <form method="post" id="newBookForm">
                       	 <div class="form-group">
                       	 	<input type="text" name="book_name" id="book_name" placeholder="اسم کتاب" class="form-control">
                       	 </div>
                       	 <div class="form-group">
                       	 	<input type="text" name="book_price" id="book_price" placeholder="قیمت کتاب" class="form-control">
                       	 </div>
                         <div class="form-group">
                            <label for="book_category">کتگوری کتاب</label>
                            <select name="book_category" class="form-control" id="book_category">
                                <option value="literature">ادبیات</option>
                                <option value="culture">فرهنگ</option>
                                <option value="politics">سیاست</option>
                                <option value="law">حقوق</option>
                            </select>
                         </div>
                         <div class="form-group">
                           <input type="Text" name="book_publisher" id="book_publisher" placeholder="ناشر" class="form-control">
                         </div>
                       	 <div class="form-group">
                       	 	<input type="date" name="publish_date" id="publish_date" placeholder="تاریخ انتشار" class="form-control usage">
                       	 </div>

                       	 <div class="form-group" id="barcodeForm">
                       	 	<input type="text" name="period" id="period" placeholder="دوره" class="form-control">
                       	 </div>
                       	 <div class="form-group">
                       	 	<input type="number" name="edition" id="edition" placeholder="ویرایش" class="form-control">
                       	 </div>
						 <div class="form-group">
                       	 	<input type="text" name="ISBN" id="ISBN" placeholder="ISBN" class="form-control">
                       	 </div>
						 <div class="form-group">
                       	 	<input type="number" name="quantity" id="quantity" placeholder="تعداد" class="form-control">
                       	 </div>
						 <div class="form-group">
                       	 	<input type="text" name="barcode" id="barcode" placeholder="بارکد" class="form-control">
                       	 </div>
						 
                       	 <div class="form-group">
                         	 	<input type="text" name="author" id="author" placeholder="نویسنده" class="form-control">
                       	 </div>
                         <div class="form-group">
                         	 	<input type="text" name="translator" id="translator" placeholder="مترجم" class="form-control">
                       	 </div>
                         
                       </form>
                       <div class="form-group">
                           <button  class="form-control btn-info" id="saveNewBook">ذخیره</button>
                         </div>
                </div>
              </div>
            </div>
            <!-- /.row -->

    </div>
    <!-- /#wrapper -->

    <div id="printArea" style="display:none;">
        <p>A simple print area</p>
        <h2>salam dustan</h2>
    </div>

    <script type="text/javascript">
        
        $('input[name=barcode]').keypress(function(e){
          if (e.keyCode == 13) {
            e.preventDefault();
            $('input[name=author]').focus();
          }
        });

        $('#saveNewBook').click(function(){
          
          var data = $('#newBookForm').serialize();
          
          $.ajax({
              method: 'post',
              dataType: 'text',
              data: data,
              async: false,
              type: 'ajax',
              url: '<?php echo base_url(); ?>BooksController/addNewBook',
              success: function(response){ 
                $('#newBookForm')[0].reset();
                $('.alert-success').fadeIn().text('A new book successfully inserted!').delay(4000).fadeOut();
                $('#printArea').css('display', 'block');
                $('#printArea').html('');
                 
              },
              error: function(){ 
                alert('faiulre 106');
              }
          });
        });

        function openPrintDialog(){
          
        }
      
    </script>






