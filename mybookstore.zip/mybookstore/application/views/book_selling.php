  <div id="page-wrapper" style="min-height: 900px !important">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">فروش کتاب</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="col-sm-3"></div>
            <div class="row col-sm-6">
              <div class="panel panel-default ">
                 <div class="panel-heading"><h4> فرم فروش کتاب</h4>
                 <div class="alert alert-success" style="display:none;">
                   
                 </div>
                 </div>

                 <div class="panel-body">
                       <form method="post" id="sellForm">
                       	 <div class="form-group">
                       	 	<input type="text" name="book_name" id="book_name" placeholder="اسم کتاب" class="form-control">
                       	 </div>
						 
						 
						           <div class="form-group">
                       	 	<input type="text" name="book_quantity" id="book_quantity" placeholder="تعداد کتاب" class="form-control">
                       	 </div>
						 
						 <div class="form-group">
                       	 	<input type="date" name="selling_date" id="selling_date" placeholder="تاریخ فورش" class="form-control">
                       	 </div>
						 
                         <div class="form-group">
                            <label for="drug_category">مشتری</label>
                            <input name="customer" class="form-control" id="customername" type="text" />
                                  
                         </div>
                        <div class="form-group">
                       	 	<input type="number" name="money_paid" id="money_paid" placeholder="پول  پرداخت شده" class="form-control">
                       	 </div>
                       	
                         
                       </form>
                          <button  name="submit"  id="saveSellBtn" class="btn btn-info">ذخیره</button>
                         
                </div>
              </div>
            </div>
            <!-- /.row -->
    
    </div>
    <!-- /#wrapper -->
    <div id="printArea" style="display:none;">
      <table class="table table-striped" border="2px red">
        <thead><h5>Dear Customer: </h5></thead>
        <tbody>
          <tr><td>Book Name</td><td id="bookName"></td></tr>
          <tr><td>Number of Books</td><td id="bookNumber"></td></tr>
          <tr><td>Sale Date</td><td id="saleDate"></td></tr>
          <tr><td>Customer Name</td><td id="customerName"></td></tr>
          <tr><td>Money Paid</td><td id="moneyPaid"></td></tr>
        </tbody>
      </table>
    </div>

<script type="text/javascript">
   $('#saveSellBtn').on('click', function(){
    var data = $('#sellForm').serialize();
    var bookname = $('#book_name').val();
    var numberofbooks = $('#book_quantity').val();
    var date = $('#selling_date').val();
    var customername = $('#customername').val();
    var moneypaid = $('#money_paid').val();

    $('#bookName').text(bookname);
    $('#bookNumber').text(numberofbooks);
    $('#saleDate').text(date);
    $('#customerName').text(customername);
    $('#moneyPaid').text(moneypaid);
    $("#printArea").css('marginLeft', '-7px');
    $('#printArea').css('display', 'block');
    $('#printArea').printThis({
      header: 'New Book Factor',
      importCss: true
    });

        $.ajax({
          method: 'post',
          url: '<?php echo base_url(); ?>BooksController/insertSoldBook',
          async: false,
          dataType: 'json',
          data: data,
          success: function(data){
            $('.alert-success').fadeIn().text('You successfully sold a new book.').delay(4000).fadeOut();
          },
          error: function(){
            alert('failure invoice');
          }
        });


   });

</script>

