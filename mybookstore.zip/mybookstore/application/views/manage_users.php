
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">مدیریت کاربران</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
              <div class="panel panel-default">
                 <div class="panel-heading"><h4>لیست کاربران</h4></div>

                 <div class="panel-body">

                   <div id="search" class="form-group col-sm-3"> 
                      <form method="post">
                          <label for="searchedWord">جستجو</label>
                          <input type="text" name="searchedWord" id="searchedWord" placeholder="جستجو" class="form-control">
                      </form>
                   </div>

                   <div id="select_record" class="form-group col-sm-2">
                        <input type="button" class="btn btn-info" value="کاربر جدید" data-toggle="modal" data-target="#addUser">
                   </div>

                     <table class="table table-striped table-bordered">
                     <tr>
                     <th>اسم </th><th width="100">تخلص</th><th>شماره تماس</th><th>شماره تذکره</th><th>ایمل آدرس</th><th>نام کابری</th><th >تنظیمات</th>
                     </tr>

                     <tr>
                         <td>احمد</td>
                         <td>محمدی</td>
                         <td>07353453453</td>
                         <td>342344</td>
                         <td>ahmad@yahoo.com</td>
                         <td>ahmad</td>
                         <td>
                           <input type="button" value="ویرایش" class="btn btn-success">
                            <input type="button" value="حذف" class="btn btn-danger">
                         </td>
                     </tr>
                       <tr>
                         <td>محمود</td>
                         <td>امیری</td>
                         <td>0787987675</td>
                         <td>908978</td>
                         <td>mahmoud@gmail.com</td>
                         <td>mahmoud</td>
                         <td><input type="button" value="ویرایش" class="btn btn-success">
                            <input type="button" value="حذف" class="btn btn-danger">
                         </td>
                     </tr>
                     </table>

                    <div class="col-sm-5"><p>شماره 1 الی 2 از 2</p></div>
                     <div class="col-sm-7">
                      <ul class="pager">
                      <li class="previous"><a href="#">قبلی</a></li>
                            
                             <ul class="pagination">
                              <li><a href="#">1</a></li>
                              <li class="active"><a href="#">2</a></li>
                              <li><a href="#">3</a></li>
                              <li><a href="#">4</a></li>
                              <li><a href="#">5</a></li>
                            </ul>
                      <li class="next"><a href="#">بعدی</a></li>
                    </ul>
                      
                  </div>
                </div>
              </div>
            </div>
            <!-- /.row -->
        

    </div>
    <!-- /#wrapper -->


  <!-- modal for adding user -->
  <div id="addUser" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">افزودن کاربر جدید</h4>
      </div>
      <div class="modal-body">
         <form method="post">
         	 <div class="form-group">
         	 	
         	 	<input type="text" class="form-control" name="uname" placeholder="نام کاربر " required>
         	 </div>
         	 <div class="form-group">
         	 	<input type="text" class="form-control" name="ulastname" placeholder="تخلص " required>
         	 </div>
         	 <div class="form-group">
         	 	<input type="text" class="form-control" name="uphone" placeholder="شماره تماس" required>
         	 </div>
         	 <div class="form-group">
         	 	<input type="text" class="form-control" name="ussn" placeholder="شماره تذکره" >
         	 </div>
         	 <div class="form-group">
         	 	<input type="text" class="form-control" name="uemail" placeholder="ایمل آدرس" required>
         	 </div>
         	  <div class="form-group">
         	 	<input type="text" class="form-control" name="username" placeholder=" نام کاربری" required>
         	 </div>
         	  <div class="form-group">
         	 	<input type="text" class="form-control" name="password" placeholder="*******" required>
         	 </div>
         	  <div class="form-group">
         	 	<input type="text" class="form-control" name="password_conf" placeholder="********" required>
         	 </div>
         	 <div class="form-group">
         	 	<textarea rows="4" class="form-control">
         	 		
         	 	</textarea>
         	 </div>
         	 <div class="form-group">
         	 	<input type="submit" class="form-control" value="ذخیره">
         	 </div>
         </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-close"></i></button>
      </div>
    </div>

  </div>
</div>

