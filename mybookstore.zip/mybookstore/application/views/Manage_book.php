
<?php 

include("include/header.php");
include("include/sidebar.php");
//start of main content 
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">لیست کتابها</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
              <div class="panel panel-default">
                 <div class="panel-heading"><h4>لیست کتابها</h4></div>

                 <div class="panel-body">
                      <div id="search" class="form-group col-sm-3"> 
                      <form method="post">
                          <label for="searchedWord">جستجو</label>
                          <input type="text" name="searchedWord" id="searchedWord" placeholder="جستجو" class="form-control">
                      </form>
                   </div>

                   <div id="select_record" class="form-group col-sm-2">
                    <label for="records">تعداد کتاب در هر صفحه</label>
                       <select name="records" id="records" class="form-control">
                           <option value="10">10</option>
                           <option value="25">25</option>
                           <option value="50">50</option>
                           <option value="100">100</option>
                       </select>
                   </div>

                     <table class="table table-striped table-bordered" id="dataTables-example">
                     <tr>
                        <th>اسم کتاب</th>
                        <th width="100">قیمت</th>
                        <th>نویسنده</th>
                        <th>مترجم</th>
                        <th>ناشر</th>
                        <th width="300">تنظیمات</th>
                     </tr>

                     <tr>
                         <td>تاریخ معاصر افغانستان</td>
                         <td>400</td>
                         <td>احمد کریمی</td>
                         <td>حسن امیری</td>
                         <td>قدس</td>
                         <td>
                           <button class="btn btn-success"><i class="fa fa-edit">&nbsp;</i>ویرایش</button>
                           <button class="btn btn-danger"><i class="fa fa-remove">&nbsp;</i>حذف</button>
                           <a href="drug_info.php" class="btn btn-warning"><i class="fa fa-info">&nbsp;</i>جزئیات کامل</a>
                         </td>
                     </tr>
                       <tr>
                         <td>آیین زندگی</td>
                         <td>500</td>
                         <td>دیل کارنگی</td>
                         <td>میترا کیوان مهر</td>
                         <td> انتشارات محصلان</td>
                         <td>
                            <button class="btn btn-success"><i class="fa fa-edit">&nbsp;</i>ویرایش</button>
                           <button class="btn btn-danger"><i class="fa fa-remove">&nbsp;</i>حذف</button>
                           <a href="drug_info.php" class="btn btn-warning"><i class="fa fa-info">&nbsp;</i>جزئیات کامل</a>
                         </td>
                     </tr>
                     </table>

                   <div class="col-sm-5"><p>شماره 1 الی 2 از 2</p></div>
                     <div class="col-sm-7">
                      <ul class="pager">
                      <li class="previous"><a href="#">قبلی</a></li>
                            
                             <ul class="pagination">
                              <li><a href="#">1</a></li>
                              <li class="active"><a href="#">2</a></li>
                              <li><a href="#">3</a></li>
                              <li><a href="#">4</a></li>
                              <li><a href="#">5</a></li>
                            </ul>
                      <li class="next"><a href="#">بعدی</a></li>
                    </ul>
                      
                  </div>

                  </div>
                </div>
              </div>
            </div>
            <!-- /.row -->
        

    </div>
    <!-- /#wrapper -->


<?php
include("include/footer.php");

?>