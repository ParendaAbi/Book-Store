
<?php 

include("include/header.php");
include("include/sidebar.php");
//start of main content 
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">لیست کتگوری ها</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
              <div class="panel panel-default">
                 <div class="panel-heading"><h4>لیست کتگوری ها</h4></div>

                 <div class="panel-body">
                     
                   
                     <table class="table table-striped table-bordered">
                     <tr>
                        <th>اسم کتگوری</th>
                        <th>توضیحات</th>
                        <th>تعداد کتاب</th>
                        <th width="300">تنظیمات</th>
                     </tr>
                    
                     <tr>
                       <td>فلسفه</td>
                       <td>توضیحات در باره کتگوری</td>
                       <td>3440</td>
                       <td>
                           <button class="btn btn-success" onclick="editCategory(3);"><i class="fa fa-edit">&nbsp;</i>ویرایش</button>
                           <button class="btn btn-danger" onclick="deleteCategory(3);"><i class="fa fa-remove">&nbsp;</i >حذف</button>
                        </td>
                     </tr>
                       <tr>
                       <td>حقوق</td>
                       <td>توضیحات در باره کتگوری</td>
                       <td>340</td>
                       <td>
                           <button class="btn btn-success" onclick="editCategory(3);"><i class="fa fa-edit">&nbsp;</i>ویرایش</button>
                           <button class="btn btn-danger" onclick="deleteCategory(3);"><i class="fa fa-remove">&nbsp;</i >حذف</button>
                        </td>
                     </tr>
                       <tr>
                       <td>تاریخ</td>
                       <td>توضیحات در باره کتگوری</td>
                       <td>450</td>
                       <td>
                           <button class="btn btn-success" onclick="editCategory(3);"><i class="fa fa-edit">&nbsp;</i>ویرایش</button>
                           <button class="btn btn-danger" onclick="deleteCategory(3);"><i class="fa fa-remove">&nbsp;</i >حذف</button>
                        </td>
                     </tr>
                       <tr>
                       <td>ادبیات</td>
                       <td>توضیحات در باره کتگوری</td>
                        <td>6000</td>
                       <td>
                           <button class="btn btn-success" onclick="editCategory(3);"><i class="fa fa-edit">&nbsp;</i>ویرایش</button>
                           <button class="btn btn-danger" onclick="deleteCategory(3);"><i class="fa fa-remove">&nbsp;</i >حذف</button>
                        </td>
                     </tr>
                     </table>

                    <div class="col-sm-5"><p>شماره 1 الی 2 از 2</p></div>
                     <div class="col-sm-7">
                      <ul class="pager">
                      <li class="previous"><a href="#">قبلی</a></li>
                            
                             <ul class="pagination">
                              <li><a href="#">1</a></li>
                              <li class="active"><a href="#">2</a></li>
                              <li><a href="#">3</a></li>
                              <li><a href="#">4</a></li>
                              <li><a href="#">5</a></li>
                            </ul>
                      <li class="next"><a href="#">بعدی</a></li>
                    </ul>
                      
                  </div>
                </div>
              </div>
            </div>
            <!-- /.row -->
        

    </div>
    <!-- /#wrapper -->


<?php
include("include/footer.php");
?>
<?php 
if(isset($_GET['msg'])){
   $message=$_GET['msg'];
  if($message=="deleted"){
     echo "<script>alert('کتگوری موفقانه حذف شد.');</script>";
  }
  else if($message=="notDeleted"){
    echo "<script>alert('لطفا دوباره کوشش کنید');</script>";
  }
}

?>

<script type="text/javascript">
function deleteCategory(id){
  var con=confirm("مطمئن هستید که کتگوری حذف شود؟");
  if(con==true){
     window.location.assign("category/deleteCategory.php?cat_id="+id);
  }
  else{

  }
}
</script>