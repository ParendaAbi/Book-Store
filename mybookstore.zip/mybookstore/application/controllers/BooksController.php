<?php

	class BooksController extends CI_Controller{

		function __construct(){
			parent::__construct();
			$this->load->model('BooksModel');
		}

		function index(){
			$this->load->view('include/header');
			$this->load->view('include/sidebar');
			$this->load->view('index');
			$this->load->view('include/footer');
		}


		function getAllBooks(){
			$result = $this->BooksModel->getAllBooks();
			if ($result) {
				echo json_encode($result);
			}
		}

		function searchBooks(){
			$key = $this->input->post('key');
			$category = $this->input->post('cat');


			$result = $this->BooksModel->searchBooks($key, $category);
			if ($result) {
				echo json_encode($result);
			}else {
				echo "Sorry! Nothing found!";
			}
		}

		function booksList(){
			$this->load->view('include/header');
			$this->load->view('include/sidebar');
			$this->load->view('books_list');
			$this->load->view('include/footer');
		}

		function sellBook(){
			$this->load->view('include/header');
			$this->load->view('include/sidebar');
			$this->load->view('book_selling.php');

			$this->load->view('include/footer');
		}


		function getBookInfo(){
			$id = $this->input->post('id');
			$bookInfo = $this->BooksModel->getBookInfo($id);
			if ($bookInfo) {
				echo json_encode($bookInfo);
			}else {
				echo 'Sorry! Could not edit!';
			}
		}

		function updateBookInfo(){
			$result = $this->BooksModel->updateBook();
			$msg['success'] = false;
			if ($result) {
				$msg['success'] = true;
			}
			return json_encode($msg);
		}

		function deleteBook(){
			$id = $this->input->post('id');
			$result = $this->BooksModel->deleteBook($id);
			$msg['success'] = false;
			if ($result) {
				$msg['success'] = true;
			}
			return json_encode($msg);
		}

		function userProfile(){
			$userdata = array('user_id' => 1);
			$this->session->set_userData($userdata);
			
			$this->load->view('include/header');
			$this->load->view('include/sidebar');
			$this->load->view('user_profile');
			$this->load->view('include/footer');
		}

		function insertSoldBook(){
			$soldData = array(
				'book_name' => $this->input->post('book_name'),
				'selling_date' => $this->input->post('selling_date'),
				'customer' => $this->input->post('customer'),
				'money_paid' => $this->input->post('money_paid')
				);
			$msg['success'] = false;
			if ($this->BooksModel->insertSoldBook($soldData)) {
				$msg['success'] = true;
			}

			echo json_encode($msg);
		}

		function addBook(){
			$this->load->view('include/header');
			$this->load->view('include/sidebar');
			$this->load->view('add_book');
			$this->load->view('include/footer');
		}



		function addNewBook(){

			$bookData = array(
				'title' => $this->input->post('book_name'),				
				'publish_date' => $this->input->post('publish_date'),
				'publisher' => $this->input->post('book_publisher'),
				'period' => $this->input->post('period'),
				'price' => $this->input->post('book_price'),
				'jeld' => $this->input->post('quantity'),
				'edition' => $this->input->post('edition'),
				'ISBN' => $this->input->post('ISBN'),
				'barcode' => $this->input->post('barcode'),
				'author' => $this->input->post('author'),
				'translator' => $this->input->post('translator'),
				'category_id' => '1'
				);

			$result = $this->BooksModel->addNewBook($bookData);
			$msg['success'] = false;
			if ($result) {
				$msg['success'] = true;
			}
			return json_encode($msg);
		}



	}

?>