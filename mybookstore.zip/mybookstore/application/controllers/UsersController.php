<?php

	class UsersController extends CI_Controller{

		function __construct(){
			parent::__construct();
			$this->load->model('UsersModel');
		}

		function getUserData(){
			$id = $this->input->post('id');
			$result = $this->UsersModel->getUserData($id);
			$msg['success'] = false;
			if ($result) {
				$msg['success'] = true;
			}
			echo json_encode($result);
		}

		function updateUserData(){
			$msg['success'] = false;
			$msg['type'] = 'updated';
			$editData = array(
				'name' => $this->input->post('name'),
				'lastname' => $this->input->post('lname'),
				'phone' => $this->input->post('phone'),
				'email' => $this->input->post('email'),
				'user_name' => $this->input->post('uname'),
				'password' => $this->input->post('pass'),
				);
			$result = $this->UsersModel->updateUserData($editData, $this->session->userdata('user_id'));
			if ($result) {
				$msg['success'] = true;
			}

			echo json_encode($msg);
		}

		function saveNewUser(){
			$msg['success'] = false;
			$msg['type'] = 'made';
			$data = array(
				'name' => $this->input->post('name'),
				'lastname' => $this->input->post('lname'),
				'phone' => $this->input->post('phone'),
				'email' => $this->input->post('email'),
				'user_name' => $this->input->post('uname'),
				'password' => $this->input->post('pass'),
				);
			$result = $this->UsersModel->saveNewUser($data);
			if ($result) {
				$msg['success'] = true;
			}

			echo json_encode($msg);
		}
	}

?>