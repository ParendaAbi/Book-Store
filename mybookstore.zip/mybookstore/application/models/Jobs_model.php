<?php
	
	class Jobs_model extends CI_Model{
		public function getJobs(){
			$this->db->select('*');
			$this->db->from('jobs');
			$this->db->join('types','jobs.type_id=types.id','INNER');
			$query = $this->db->get();
			return $query->result();
		}

		public function getJobsCategories(){
			$this->db->select('*');
			$this->db->from('categories');
			$query = $this->db->get();
			return $query->result();
		}

		public function getJobById($id){
			$this->db->select('*');
			$this->db->from('jobs');
			$this->db->where('jobs.id',$id);
			$this->db->join('types','jobs.type_id=types.id','INNER');
			$query = $this->db->get();
			return $query->row();
		}

		public function getJobsByCategory($id){
			$this->db->select('*');
			$this->db->from('jobs');
			$this->db->where('category_id',$id);
			$this->db->join('types','jobs.type_id=types.id','INNER');
			$query = $this->db->get();
			return $query->result();
		}

	}

?>