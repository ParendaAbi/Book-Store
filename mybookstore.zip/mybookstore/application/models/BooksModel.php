<?php

	class BooksModel extends CI_Model{
		function __construct(){
			parent::__construct();
		}

		function getAllBooks(){
			$result = $this->db->get('book');
			if ($result) {
				return $result->result();
			}else {
				return null;
			}
		}

		function searchBooks($key, $category){
			 
			$this->db->like($category, $key);
			$result = $this->db->get('book');

			if ($result) {
				return $result->result();
			}else {
				return null;
			}
		}

		function getBookInfo($id){
			
			$this->db->where('book_id', $id);
			$result = $this->db->get('book');
			if ($result) {
				return $result->row();
			}else {
				return null;
			}
		}

		function updateBook(){
			$this->db->where('book_id', $this->input->post('hiddenId'));
			$data = array(
				'title' => $this->input->post('book_name'),
				'price' => $this->input->post('price'),
				'publish_date' => $this->input->post('pub_date'),
				'author' => $this->input->post('writer'),
				'translator' => $this->input->post('translator'),
				'publisher' => $this->input->post('publish')
				);
			$result = $this->db->update('book', $data);
			if ($result) {
				return true;
			}else {
				return null;
			}
		}

		function deleteBook($id){
			$this->db->where('book_id', $id);
			if ($this->db->delete('book')) {
				return true;
			}else {
				return false;
			}
		}

		function insertSoldBook($soldBook){
			if ($this->db->insert('invoice', $soldBook)) {
				return true;
			}else {
				return false;
			}
		}

		function addNewBook($data){
			if ($this->db->insert('book', $data)) {
				return true;
			}else{
				return false;
			}
		}


	}


?>