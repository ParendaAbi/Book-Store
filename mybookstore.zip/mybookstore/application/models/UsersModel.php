<?php
	
	class UsersModel extends CI_Model{

		function __construct(){
			parent::__construct();
		}

		public function register(){
			$data = array(
				'firstname' => $this->input->post('first_name'),
				'lastname' => $this->input->post('last_name'),
				'email' => $this->input->post('email'),
				'username' => $this->input->post('username'),
				'role' => $this->input->post('role'),
				'password' => md5($this->input->post('password'))

				);
			$insert = $this->db->insert('users',$data);
			return $insert;
		}

		public function login($username, $password){
			$this->db->where('username',$username);
			$this->db->where('password', $password);
			$result = $this->db->get('users');
			if ($result->num_rows == 1) {
				return $result->row(0)->id; 
			}else {
				return false;
			}
		}

		function getUserData($id){
			$this->db->where('id', $id);
			$result = $this->db->get('user');
			if ($result) {
				return $result->row();
			}else {
				return false;
			}
		}

		function updateUserData($data, $id){
			$this->db->where('id', $id);
			$this->db->update('user', $data);

			if ($this->db->affected_rows() > 0) {
				return true;
			}else {
				return false;
			}
		}

		function saveNewUser($data){
			$result = $this->db->insert('user', $data);
			if ($result) {
				return true; 
			}else {
				return false;
			}
		}


	}



?>